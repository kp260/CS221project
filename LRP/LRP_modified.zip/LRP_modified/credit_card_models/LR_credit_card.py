'''
@author: Vignesh Srinivasan
@author: Sebastian Lapuschkin
@author: Gregoire Montavon
@maintainer: Vignesh Srinivasan
@maintainer: Sebastian Lapuschkin 
@contact: vignesh.srinivasan@hhi.fraunhofer.de
@date: 20.12.2016
@version: 1.0+
@copyright: Copyright (c)  2016-2017, Vignesh Srinivasan, Sebastian Lapuschkin, Alexander Binder, Gregoire Montavon, Klaus-Robert Mueller, Wojciech Samek
@license : BSD-2-Clause
'''

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import sys
sys.path.append("..")
from modules.sequential import Sequential
from modules.linear import Linear
from modules.utils import Utils

import pandas as pd
import os
os.environ['TF_CPP_MIN_LOG_LEVEL']='2'
import tensorflow as tf
import numpy as np

flags = tf.flags
logging = tf.logging
max_steps = 3000
test_every = max_steps - 1
train_cases = 24000
batch_size = 32
test_steps = int((30000 - train_cases)/batch_size)

flags.DEFINE_integer("max_steps", max_steps,'Number of steps to run trainer.')
flags.DEFINE_integer("test_steps", test_steps,'Number of steps to run trainer.')
flags.DEFINE_integer("batch_size", batch_size,'Number of steps to run trainer.')
flags.DEFINE_integer("test_every", test_every,'Number of steps to run trainer.')
flags.DEFINE_float("learning_rate", 0.001,'Initial learning rate')
flags.DEFINE_float("dropout", 1, 'Keep probability for training dropout.')
flags.DEFINE_string("data_dir", 'data','Directory for storing data')
flags.DEFINE_string("summaries_dir", 'lending_linear_logs','Summaries directory')
flags.DEFINE_boolean("relevance", True,'Compute relevances')
flags.DEFINE_string("relevance_method", 'ww','relevance methods: simple/epsilon/ww/flat/alphabeta')
flags.DEFINE_boolean("save_model", False,'Save the trained model')
flags.DEFINE_boolean("reload_model", False,'Restore the trained model')
flags.DEFINE_string("checkpoint_dir", 'lending_linear_model','Checkpoint dir')
flags.DEFINE_boolean("normalize_data", True, "Normalize the input dataset")
flags.DEFINE_boolean("rel_floor_removal", False, "Rescales all relevance outputs by removing the min")

# Feature definition
data_cols = ['ID','LIMIT_BAL',	'SEX',	'EDUCATION',	'MARRIAGE',	'AGE',
             'PAY_1', 'PAY_2', 'PAY_3', 'PAY_4', 'PAY_5', 'PAY_6', 
             'BILL_AMT1','BILL_AMT2','BILL_AMT3','BILL_AMT4','BILL_AMT5','BILL_AMT6',                                           
             'PAY_AMT1','PAY_AMT2','PAY_AMT3','PAY_AMT4','PAY_AMT5','PAY_AMT6']

output_cols = data_cols.copy()
output_cols.remove('ID')
output_cols.append('ID')
output_cols.append('EVAL')
output_cols.append('ACTUAL DEFAULT')
output_cols.append('TYPE')


# The -1 is to include the ID
nfeatures = len(data_cols) - 1

FLAGS = flags.FLAGS

def collect_rows_to_write(input_labels, default_labels, ID_labels, relevance_test, sigmoid_eval):
    rows_to_write = []
    
    if FLAGS.rel_floor_removal:
        for subject in relevance_test:
            row = []
            min_rel = min(subject)
            subj_sum = sum(subject)
            rescaling_factor = subj_sum / (subj_sum - nfeatures*min_rel)
            rescaled_sum = 0
            
            for feature_contribution in subject:
                rescaled_feature_contr = rescaling_factor * (feature_contribution - min_rel)
                row.append(rescaled_feature_contr)
                rescaled_sum += rescaled_feature_contr
            #row.append(rescaled_sum)
            rows_to_write.append(row[:])
    else:
        for subject in relevance_test:
            row = []
            for feature_contribution in subject:
                row.append(feature_contribution)
            #row.append(sum(subject))
            rows_to_write.append(row[:])
    
    for e in range(len(rows_to_write)):
        rows_to_write[e].append(ID_labels[e])
        sigmoid_score = sigmoid_eval[e][0]
        default_flag = default_labels[e][0]
        rows_to_write[e].append(sigmoid_score)
        rows_to_write[e].append(default_flag)
        model_prediction = sigmoid_score > 0.5
        if (model_prediction == True and default_flag == 1):
            rows_to_write[e].append("TruePos")
        elif (model_prediction == True and default_flag == 0):
            rows_to_write[e].append("FalsePos")
        elif (model_prediction == False and default_flag == 0):
            rows_to_write[e].append("TrueNeg")
        elif (model_prediction == False and default_flag == 1):
            rows_to_write[e].append("FalseNeg")
        else:
            rows_to_write[e].append("ERROR!")
            
    return rows_to_write
 
def output_csv_from_rows(rows_to_write):
    output_filepath = "LRP_RESULTS_" + FLAGS.relevance_method + ".xlsx"
    #print("output", rows_to_write)
    output_results = pd.DataFrame(rows_to_write)
    output_results.columns = output_cols
    writer = pd.ExcelWriter(output_filepath)
    #output_results.to_excel(writer, "LRP Results", index = False)
    
    output_results.to_excel("output.xlsx")

def output_custom_csv_standalone(input_labels, default_labels, relevance_test, sigmoid_eval):
    rows_to_write = []
            
    if FLAGS.rel_floor_removal:
        for subject in relevance_test:
            row = []
            min_rel = min(subject)
            subj_sum = sum(subject)
            rescaling_factor = subj_sum / (subj_sum - nfeatures*min_rel)
            rescaled_sum = 0
            
            for feature_contribution in subject:
                rescaled_feature_contr = rescaling_factor * (feature_contribution - min_rel)
                row.append(rescaled_feature_contr)
                rescaled_sum += rescaled_feature_contr
            row.append(rescaled_sum)
            rows_to_write.append(row[:])
    else:
        for subject in relevance_test:
            row = []
            for feature_contribution in subject:
                row.append(feature_contribution)
            row.append(sum(subject))
            rows_to_write.append(row[:])
    
    print(len(relevance_test))
    print(len(rows_to_write))     
    print(len(rows_to_write[0]))          
            
    for e in range(len(rows_to_write)):
        rows_to_write[e].append(sigmoid_eval[e][0])
        rows_to_write[e].append(default_labels[e][0])
            
    output_filepath = "LRP_RESULTS_" + FLAGS.relevance_method + ".xlsx"
    output_results = pd.DataFrame(rows_to_write)
    output_results.columns = output_cols
    writer = pd.ExcelWriter(output_filepath)
    output_results.to_excel(writer, "LRP Results", index = False)
    

#................................................
def data_load(path):
    
    # load lending data and split into train and test datasets
    print("\n")
    print("Loading data file ...\n")
    data_set = pd.read_csv(path,header=0)

    data_set = data_set.sample(frac = 1).reset_index(drop=True)
    data_set['Default'] = data_set['Default'].apply(pd.to_numeric, downcast = 'integer', errors = 'coerce')
    # Normalize columns 
    
    if FLAGS.normalize_data:
        cols_to_norm = ['LIMIT_BAL','EDUCATION',	'MARRIAGE',	'AGE', 'BILL_AMT1','BILL_AMT2','BILL_AMT3','BILL_AMT4','BILL_AMT5','BILL_AMT6',                                           
                'PAY_AMT1','PAY_AMT2','PAY_AMT3','PAY_AMT4','PAY_AMT5','PAY_AMT6']
        data_set[cols_to_norm] = data_set[cols_to_norm].apply(lambda x: (x - x.min()) / (x.max()-x.min()))

    # create dummies for categorical features.
    # add 2 to all the values because OneHotEncoder can only handle non-negative values
    # =================================================================================
    
    col_pay = ['PAY_1', 'PAY_2', 'PAY_3', 'PAY_4', 'PAY_5', 'PAY_6']
    data_set[col_pay] = data_set[col_pay].apply(lambda x: x+2)
    # =================================================================================

    print("Splitting into train and test datasets ...\n")
    
    
    train_threshold = len(data_set) - train_cases
    test_threshold = train_threshold - 1
    
    X_test = data_set.loc[0:test_threshold, data_cols]
    Y_test = data_set.loc[0:test_threshold,'Default']
    
    X_train = data_set.loc[train_threshold:,data_cols]
    Y_train = data_set.loc[train_threshold:,'Default']
    
    X_test = pd.DataFrame.as_matrix(X_test)
    X_train = pd.DataFrame.as_matrix(X_train)
    Y_test = pd.DataFrame.as_matrix(Y_test)
    Y_train = pd.DataFrame.as_matrix(Y_train)
    
    if FLAGS.normalize_data:
        Y_test = Y_test.astype(float)
        Y_train = Y_train.astype(float)
    
    Y_test = np.reshape(Y_test, [Y_test.shape[0],1])
    Y_train = np.reshape(Y_train, [Y_train.shape[0], 1])
    print("Done.\n")
    
    return X_train, Y_train, X_test, Y_test

def get_XY_iterators(X, Y, sess, buffer_size = 1):
    dataset = tf.concat([X, Y], axis = 1)
    dataset = tf.convert_to_tensor(dataset)
    dataset = tf.data.Dataset.from_tensor_slices(dataset)
    dataset = dataset.shuffle(buffer_size)
    
    dataset = dataset.apply(tf.contrib.data.batch_and_drop_remainder(FLAGS.batch_size))
    iteratorX = dataset.make_initializable_iterator()
    iteratorY = dataset.make_initializable_iterator()
    iteratorID = dataset.make_initializable_iterator()
    sess.run(iteratorX.initializer)
    sess.run(iteratorY.initializer)
    sess.run(iteratorID.initializer)
    next_elementX = iteratorX.get_next()
    next_elementY = iteratorY.get_next()
    next_elementID = iteratorID.get_next()
    return next_elementX, next_elementY, next_elementID
    
def input_fn_v3(next_elementX, next_elementY, next_elementID):
    # Load all the dataset in memory for shuffling is training  
    
    ID = next_elementID[:, 0]
    X = next_elementX[:, 1:nfeatures+1]
    Y = next_elementY[:, nfeatures+1:]

    # Build and return a dictionary containing the nodes / ops
    inputs = { 'features': X,
               'labels': Y,
               'ID': ID
    }
    
    return inputs

#....................................................
def nn():
    return Sequential([Linear(input_dim=nfeatures,output_dim=1, act ='linear', batch_size=FLAGS.batch_size, keep_prob=1),
                     Linear(output_dim=1, act = 'linear')
                     
     #return Sequential([Linear(input_dim=nfeatures,output_dim=1, act ='linear', batch_size=FLAGS.batch_size, keep_prob=1)               
    ])



def train():
  # Import data
  X_train, Y_train, X_test, Y_test = data_load(path = "./Taiwan_credit_card.csv")
   
  with tf.Session() as sess:
       
    # Input placeholders
    with tf.name_scope('input'):
        x = tf.placeholder(tf.float32, [FLAGS.batch_size, nfeatures], name='x-input')
        y_ = tf.placeholder(tf.float32, [FLAGS.batch_size, 1], name='y-input')
        keep_prob = tf.placeholder(tf.float32)
    

    # Model definition along with training and relevances
    with tf.variable_scope('model'):
        net = nn()
        y = net.forward(x)
        
        
        
    with tf.variable_scope('relevance'):    
        if FLAGS.relevance:
            
            y_sigmoid = tf.sigmoid(y)
            LRP = net.lrp(tf.cast(y_sigmoid, tf.float32),FLAGS.relevance_method, 1)
            
            # LRP layerwise 
            relevance_layerwise = []
            R = y
            for layer in net.modules[::-1]:
                R = net.lrp_layerwise(layer, R, 'alphabeta',1)
                relevance_layerwise.append(R)
        else:
            LRP = []
            relevance_layerwise = []
            
    # Accuracy computation
    with tf.name_scope('correct_prediction'):
        y_acc = tf.sigmoid(y)
        y_acc = y_acc>0.5
        tf_yacc = tf.cast(y_acc, tf.int32)
        correct_prediction = tf.equal(tf_yacc, tf.cast(y_, tf.int32))
        accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    tf.summary.scalar('accuracy', accuracy)

    # Merge all the summaries and write them out 
    merged = tf.summary.merge_all()
    train_writer = tf.summary.FileWriter(FLAGS.summaries_dir + '/train', sess.graph)
    test_writer = tf.summary.FileWriter(FLAGS.summaries_dir + '/test')

    tf.global_variables_initializer().run()
    
    utils = Utils(sess, FLAGS.checkpoint_dir)
    if FLAGS.reload_model:
        utils.reload_model()

    #trainer = net.fit(output=y,ground_truth=y_,loss='sigmoid_crossentropy',optimizer='adam', opt_params=[FLAGS.learning_rate])
    trainer = net.fit(output=y,ground_truth=y_,loss='weighted_sigmoid_ce',optimizer='adam', opt_params=[FLAGS.learning_rate])

    uninit_vars = set(tf.global_variables()) - set(tf.trainable_variables())
    tf.variables_initializer(uninit_vars).run()
            
       
    # iterate over train and test data
    sum_acc = 0
    
    test_iteratorX, test_iteratorY, test_iteratorID = get_XY_iterators(X_test, Y_test, sess)
    train_iteratorX, train_iteratorY, train_iteratorID = get_XY_iterators(X_train, Y_train, sess)
    steps_to_exhaust_batches = int(train_cases / FLAGS.batch_size)
    
    # Training loop
    for i in range(FLAGS.max_steps):
        
        if i % steps_to_exhaust_batches == 0:
            train_iteratorX, train_iteratorY, train_iteratorID = get_XY_iterators(X_train, Y_train, sess)
            
        train_inputs = input_fn_v3(train_iteratorX, train_iteratorY, train_iteratorID)
        inp = {x:train_inputs['features'].eval(), y_: train_inputs['labels'].eval(), keep_prob:1}
            
        summary,acc,  _ , relevance_train,op, rel_layer= sess.run([merged, accuracy, trainer.train, [],y, []], feed_dict=inp)
        train_writer.add_summary(summary, i)
        sum_acc += acc
        av_acc = sum_acc/(i+1)
        #print('Training accuracy at step %s: %f' % (i, acc))
        #print('Average training accuracy at step %s: %f' % (i, av_acc))
    
    # Testing loop
    rows_to_write = []
    for i in range(FLAGS.test_steps):

        test_inputs = input_fn_v3(test_iteratorX, test_iteratorY, test_iteratorID)
            
        default_labels = test_inputs['labels'].eval()
        input_labels = test_inputs['features'].eval()
        ID_labels = test_inputs['ID'].eval()
            
        test_inp = {x:input_labels, y_: default_labels, keep_prob:1}
        summary, acc , relevance_test, op, rel_layer= sess.run([merged, accuracy, LRP,y, relevance_layerwise], feed_dict=test_inp)
        test_writer.add_summary(summary, i)
        #print('Evaluation accuracy at step %s: %f' % (i, acc))
        
        sigmoid_eval = tf.sigmoid(op).eval()
        rows_to_write.extend(collect_rows_to_write(input_labels, default_labels, ID_labels, relevance_test, sigmoid_eval))
        
    output_csv_from_rows(rows_to_write)
        
    train_writer.close()
    test_writer.close()


def main(_):
    if tf.gfile.Exists(FLAGS.summaries_dir):
        tf.gfile.DeleteRecursively(FLAGS.summaries_dir)
    tf.gfile.MakeDirs(FLAGS.summaries_dir)
    train()


if __name__ == '__main__':
    tf.app.run()
